//@dart=2.9
// ignore_for_file: import_of_legacy_library_into_null_safe, missing_return
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'Bottom Menu/Home/home_menu.dart';
import 'Bottom Menu/Search/search_menu.dart';
import 'Bottom Menu/Video/video_news.dart';
import 'Drawer Menu/drawer_menus.dart';
import 'app_bar_view.dart';

class DashboardView extends StatefulWidget {
  const DashboardView({Key key}) : super(key: key);

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {

  SharedPreferences loginData;
  String deviceId;

  @override
  void initState() {
    intll();
    super.initState();
  }
  void intll() async {
    loginData = await SharedPreferences.getInstance();
    loginData.setBool('login', false);
    setState(() {
      deviceId = loginData.getString('device_id');
    });
    print("deviceID ==> $deviceId");
  }

  int _currentIndex = 0;
  final List _children = [
    const HomeMenu(),
    const VideoMenu(),
    const SearchMenu(),
  ];
  void onTapScreen(int index){
    setState(() {
      _currentIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: DrawerMenus(),
      appBar: AppBarHomePage(cindex: _currentIndex),
      body: _children[_currentIndex],
      bottomSheet: BottomNavigationBar(
          elevation: 0,
          currentIndex: _currentIndex,
          selectedItemColor: Colors.white,
          onTap: onTapScreen,
          backgroundColor: _currentIndex == 1 ? Colors.transparent : const Color(0xff4d114e),
          type: BottomNavigationBarType.fixed,
          unselectedItemColor: Colors.white60,
          items: <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Image(image: const AssetImage("Assets/images/icons/home.png"),width: 20,color: _currentIndex == 0 ? Colors.white : Colors.white60),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Image(image: const AssetImage("Assets/images/icons/video.png"),width: 20,color: _currentIndex == 1 ? Colors.white : Colors.white60),
              label: 'Video',
            ),
            BottomNavigationBarItem(
              icon: Image(image: const AssetImage("Assets/images/icons/search.png"),width: 20,color: _currentIndex == 2 ? Colors.white : Colors.white60),
              label: 'Search',
            ),
          ]
      ),
    );
  }
}
