//@dart=2.9
// ignore_for_file: non_constant_identifier_names

import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:new_gujarati_news/App%20Helper/Model/general_news_model.dart';
import '../../../App Helper/Api Future/api_future.dart';
import '../../../App Helper/Api Urls/api_url.dart';
import '../../../App Helper/Service/share_data.dart';
import '../../../App Helper/Ui Helper/color_and_font_helper.dart';
import '../../../App Helper/Ui Helper/data_helper.dart';
import '../../../App Helper/Ui Helper/image_error_helper.dart';
import '../../../App Helper/Ui Helper/image_helper.dart';
import '../../../App Helper/Ui Helper/loading_helper.dart';
import 'exclusive_news.dart';
import 'home_menu_categorys.dart';
import 'news_details_page.dart';

class HomeMenu extends StatefulWidget {
  const HomeMenu({Key key}) : super(key: key);
  @override
  State<HomeMenu> createState() => _HomeMenuState();
}

class _HomeMenuState extends State<HomeMenu> {
  bool isLoading;
  var finalDate;
  @override
  void initState() {
    DateTime now = DateTime.now();
    DateTime today = DateTime(now.year, now.month, now.day);
    finalDate = today.toString().split(" ")[0];
    super.initState();
    getNews();
    Future.delayed(const Duration(seconds: 1),(){
      setState(() {
        getENews();
      });
    });
    isLoading = true;
  }

  Future refreshList() async {
    await Future.delayed(const Duration(seconds: 1));
    getNews();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      height: MediaQuery.of(context).size.height / 1.2,
      child: RefreshIndicator(
        color: RedColor,
        backgroundColor: Colors.white,
        onRefresh: () async {
          await refreshList();
        },
        child: AnimationLimiter(
          child: isLoading == false
              ? allNews == null ? const LoadingHelper() : allNews.isNotEmpty ? ListView.builder(
            physics: const BouncingScrollPhysics(),
            scrollDirection: Axis.vertical,
            itemCount: 15,
            itemBuilder: (context, index){
              return AnimationConfiguration.staggeredList(
                position: index,
                duration: const Duration(milliseconds: 1000),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    index == 0
                      ? eNewsSData.isEmpty
                        ? Container()
                        : eNewsSData[0].startedAt.toString().split(' ')[0] == finalDate
                          ? HomeExclusiveNews(eNewsSData: eNewsSData,isLoading: isLoading)
                          : Container()
                      : Container(),

                    index == 0
                      ? eNewsSData.isEmpty
                        ? InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>NewsDetailsPage(
                            categorynm: allNews[index].categoryName,
                            categoryid: allNews[index].categoryId,
                            title: allNews[index].title,
                            en_title: allNews[index].enTitle,
                            news_image: allNews[index].newsImage,
                            banner_description: allNews[index].bannerDescription,
                            description: allNews[index].description,
                            slug: allNews[index].slug,
                            started_at: allNews[index].startedAt,
                            ended_at: allNews[index].endedAt,
                            status: "${allNews[index].status}",
                            author_id: "${allNews[index].authorId}",
                            author_image: allNews[index].authorImage,
                            name: allNews[index].name,
                            image: allNews[index].authorImage,
                            tags: allNews[index].tags,
                          )));
                        },
                        child: SlideAnimation(
                          horizontalOffset: 75.0,
                          child: FadeInAnimation(
                            child: Container(
                              height: MediaQuery.of(context).size.height / 3.5,
                              width: MediaQuery.of(context).size.width,
                              color: Colors.red,
                              child: Stack(
                                children: [
                                  allNews[index].newsImage != null ? CachedNetworkImage(
                                    imageUrl: allNews[index].newsImage,
                                    imageBuilder: (context, imageprovider) => Container(
                                      height: MediaQuery.of(context).size.height / 3.5,
                                      width: MediaQuery.of(context).size.width,
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(0),
                                          image: DecorationImage(
                                              image: imageprovider,
                                              fit: BoxFit.cover,
                                              colorFilter: const ColorFilter.mode(Colors.transparent, BlendMode.colorBurn)
                                          )
                                      ),
                                    ),
                                    placeholder: (context, url) => Center(child: CircularProgressIndicator(color: RedColor,strokeWidth: 3.0)),
                                    errorWidget: (context, url, error) => const ImageMainErrorHelper(),
                                  ) : const ImageMainErrorHelper(),
                                  Container(
                                    width: MediaQuery.of(context).size.width,
                                    height: MediaQuery.of(context).size.height / 3.5,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(0),
                                      gradient: LinearGradient(
                                          colors: [
                                            Colors.black12,
                                            Colors.black.withOpacity(0.8)
                                          ],
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter
                                      ),
                                    ),
                                    padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
                                    child: Column(
                                      children: [
                                        const Spacer(),
                                        allNews[index].tags != null ? Container(
                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(5),color: RedColor.withOpacity(0.5)),
                                          padding: const EdgeInsets.fromLTRB(10, 2, 10, 2),
                                          child: Text(
                                            allNews[index].tags[0].name ?? "",
                                            style: const TextStyle(fontFamily: FontType.PoppinsMedium,color: Colors.white,letterSpacing: 0.5),
                                          ),
                                        ) : Container(),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(8, 5, 8, 5),
                                          child: Text(
                                            allNews[index].title ?? "",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontFamily: FontType.AnekGujaratiSemiBold,letterSpacing: 1,color: Colors.white,fontSize: 16),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                    )
                        : eNewsSData[0].startedAt.toString().split(' ')[0] == finalDate
                          ? Container()
                          : InkWell(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context)=>NewsDetailsPage(
                            categorynm: allNews[index].categoryName,
                            categoryid: allNews[index].categoryId,
                            title: allNews[index].title,
                            en_title: allNews[index].enTitle,
                            news_image: allNews[index].newsImage,
                            banner_description: allNews[index].bannerDescription,
                            description: allNews[index].description,
                            slug: allNews[index].slug,
                            started_at: allNews[index].startedAt,
                            ended_at: allNews[index].endedAt,
                            status: "${allNews[index].status}",
                            author_id: "${allNews[index].authorId}",
                            author_image: allNews[index].authorImage,
                            name: allNews[index].name,
                            image: allNews[index].authorImage,
                            tags: allNews[index].tags,
                          )));
                        },
                        child: SlideAnimation(
                          horizontalOffset: 75.0,
                          child: FadeInAnimation(
                            child: Container(
                              height: MediaQuery.of(context).size.height / 3.5,
                              width: MediaQuery.of(context).size.width,
                              color: Colors.red,
                              child: Stack(
                                children: [
                                  allNews[index].newsImage != null ? CachedNetworkImage(
                                    imageUrl: allNews[index].newsImage,
                                    imageBuilder: (context, imageprovider) => Container(
                                      height: MediaQuery.of(context).size.height / 3.5,
                                      width: MediaQuery.of(context).size.width,
                                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(0),
                                          image: DecorationImage(
                                              image: imageprovider,
                                              fit: BoxFit.cover,
                                              colorFilter: const ColorFilter.mode(Colors.transparent, BlendMode.colorBurn)
                                          )
                                      ),
                                    ),
                                    placeholder: (context, url) => Center(child: CircularProgressIndicator(color: RedColor,strokeWidth: 3.0)),
                                    errorWidget: (context, url, error) => const ImageMainErrorHelper(),
                                  ) : const ImageMainErrorHelper(),
                                  Container(
                                    width: MediaQuery.of(context).size.width,
                                    height: MediaQuery.of(context).size.height / 3.5,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(0),
                                      gradient: LinearGradient(
                                          colors: [
                                            Colors.black12,
                                            Colors.black.withOpacity(0.8)
                                          ],
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter
                                      ),
                                    ),
                                    padding: const EdgeInsets.fromLTRB(12, 5, 12, 5),
                                    child: Column(
                                      children: [
                                        const Spacer(),
                                        allNews[index].tags != null ? Container(
                                          decoration: BoxDecoration(borderRadius: BorderRadius.circular(5),color: RedColor.withOpacity(0.5)),
                                          padding: const EdgeInsets.fromLTRB(10, 2, 10, 2),
                                          child: Text(
                                            allNews[index].tags[0].name ?? "",
                                            style: const TextStyle(fontFamily: FontType.PoppinsMedium,color: Colors.white,letterSpacing: 0.5),
                                          ),
                                        ) : Container(),
                                        Padding(
                                          padding: const EdgeInsets.fromLTRB(8, 5, 8, 5),
                                          child: Text(
                                            allNews[index].title ?? "",
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(fontFamily: FontType.AnekGujaratiSemiBold,letterSpacing: 1,color: Colors.white,fontSize: 16),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                    )
                      : Container(),
                    index == 0 ? const SizedBox(height: 10) : Container(),

                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 5, 0, 8),
                      child: SlideAnimation(
                        horizontalOffset: 75.0,
                        child: FadeInAnimation(
                          child: Container(
                            width: MediaQuery.of(context).size.width,
                            height: MediaQuery.of(context).size.height / 8.8,
                            //color: Colors.teal,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(10, 0, 0, 0),
                                  child: InkWell(
                                    onTap: (){
                                      Navigator.push(context, MaterialPageRoute(builder: (context)=>NewsDetailsPage(
                                        categorynm: allNews[index].categoryName,
                                        categoryid: allNews[index].categoryId,
                                        title: allNews[index].title,
                                        en_title: allNews[index].enTitle,
                                        news_image: allNews[index].newsImage,
                                        banner_description: allNews[index].bannerDescription,
                                        description: allNews[index].description,
                                        slug: allNews[index].slug,
                                        started_at: allNews[index].startedAt,
                                        ended_at: allNews[index].endedAt,
                                        status: "${allNews[index].status}",
                                        author_id: "${allNews[index].authorId}",
                                        author_image: allNews[index].authorImage,
                                        name: allNews[index].name,
                                        image: allNews[index].authorImage,
                                        tags: allNews[index].tags,
                                        newslink: allNews[index].newsLink,
                                      )));
                                    },
                                    child: Container(
                                      //color: Colors.yellow,
                                      width: MediaQuery.of(context).size.width / 3,
                                      height: MediaQuery.of(context).size.height / 8.8,
                                      child: allNews[index].newsImage != null ? CachedNetworkImage(
                                        imageUrl: allNews[index].newsImage,
                                        imageBuilder: (context, imageProvider) => Container(
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            image: DecorationImage(
                                                image: imageProvider,
                                                fit: BoxFit.cover,
                                                colorFilter: const ColorFilter.mode(Colors.transparent, BlendMode.colorBurn)
                                            ),
                                          ),
                                        ),
                                        placeholder: (context, url) => Center(child: CircularProgressIndicator(color: RedColor,strokeWidth: 3.0,)),
                                        errorWidget: (context, url, error) => const ImageHomePageSubError(),
                                      ) : const ImageHomePageSubError(),
                                    ),
                                  ),
                                ),
                                Container(
                                  //color: Colors.green,
                                  width: MediaQuery.of(context).size.width / 1.6,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Row(
                                        children: [
                                          Text(
                                            allNews[index].categoryName ?? "",
                                            style: const TextStyle(fontFamily: FontType.PoppinsMedium,letterSpacing: 0.5,fontSize: 10,color: Colors.red),
                                          ),
                                          const Spacer(),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.end,
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              //Image(image: AppImageIcons().BookmarkImageIcon,color: RedColor,width: 15),
                                              const SizedBox(width: 10),
                                              InkWell(
                                                onTap: (){
                                                  ShareData().shareData(
                                                    allNews[index].title,
                                                    allNews[index].newsLink,
                                                  );
                                                },
                                                child: Image(
                                                  image: AppImageIcons().ShareImageIcon,
                                                  color: RedColor,width: 20,
                                                ),
                                              ),
                                              const SizedBox(width: 10),
                                            ],
                                          )
                                        ],
                                      ),
                                      Container(
                                        width: MediaQuery.of(context).size.width / 1.7,
                                        //color: Colors.yellow,
                                        child: InkWell(
                                          onTap: (){
                                            Navigator.push(context, MaterialPageRoute(builder: (context)=>NewsDetailsPage(
                                              categorynm: allNews[index].categoryName,
                                              categoryid: allNews[index].categoryId,
                                              title: allNews[index].title,
                                              en_title: allNews[index].enTitle,
                                              news_image: allNews[index].newsImage,
                                              banner_description: allNews[index].bannerDescription,
                                              description: allNews[index].description,
                                              slug: allNews[index].slug,
                                              started_at: allNews[index].startedAt,
                                              ended_at: allNews[index].endedAt,
                                              status: "${allNews[index].status}",
                                              author_id: "${allNews[index].authorId}",
                                              author_image: allNews[index].authorImage,
                                              name: allNews[index].name,
                                              image: allNews[index].authorImage,
                                              tags: allNews[index].tags,
                                              newslink: allNews[index].newsLink,
                                            )));
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.fromLTRB(0, 0, 5, 0),
                                            child: Text(
                                              allNews[index].title ?? "",
                                              maxLines: 3,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(fontSize: 14,fontFamily: FontType.AnekGujaratiSemiBold),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    index == 14 ? const HomeMenuCategory() : Container(),
                  ],
                ),
              );
            },
          ) : const DataHelper()
              : const LoadingHelper(),
        ),
      ),
    );
  }

  Widget SizeBox(){
    return const SizedBox(height: 10);
  }

  Future<GeneralNewsModel> allNewsOBJ;
  List<GNews> allNewsSData = [];
  List<GData> allNewsMData = [];
  List<GNews> allNews;

  getNews() async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await ApiFuture().generalNews(ApiUrl.AllNews);
      final newsList = response.data.news;
      final uniqueNews = newsList.toSet();
      allNews = uniqueNews.toList();
      setState(() {
        isLoading = false;
      });
    } on SocketException {
      setState(() {
        isLoading = false;
      });
      Fluttertoast.showToast(
        msg: "Internet Connection Problem",
        backgroundColor: PurpleColor,
        textColor: Colors.white,
      );
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Fluttertoast.showToast(
        msg: "Please Try Again",
        backgroundColor: PurpleColor,
        textColor: Colors.white,
      );
      print("Error: $e");
    }
  }

  Future<GeneralNewsModel> eNewsOBJ;
  List<GNews> eNewsSData = [];
  List<GData> eNewsMData = [];
  List<GNews> eNews;
  getENews() async {
    setState(() {
      isLoading = true;
    });
    try {
      eNewsOBJ = ApiFuture().eNews(ApiUrl.AllNews);
      await eNewsOBJ.then((value) async {
        eNewsSData.addAll(value.data.news);
        eNewsMData.add(value.data);
      });
      setState(() {
        isLoading = false;
      });
    } on SocketException {
      setState(() {
        isLoading = false;
      });
      Fluttertoast.showToast(msg: "Internet Connection Problem",backgroundColor: PurpleColor,textColor: Colors.white);
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      Fluttertoast.showToast(msg: "Data Fetching Error",backgroundColor: PurpleColor,textColor: Colors.white);
      print("e $e");
    }
    setState(() {});
  }
}
