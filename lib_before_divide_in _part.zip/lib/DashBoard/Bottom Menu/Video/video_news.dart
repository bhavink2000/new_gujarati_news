//@dart=2.9
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:new_gujarati_news/App%20Helper/Model/video_news_model.dart';
import 'package:video_player/video_player.dart';
import '../../../App Helper/Api Future/api_future.dart';
import '../../../App Helper/Api Urls/api_url.dart';
import '../../../App Helper/Ui Helper/color_and_font_helper.dart';
import 'video_bottom_side.dart';
import 'video_side.dart';

class VideoMenu extends StatefulWidget {
  const VideoMenu({Key key}) : super(key: key);

  @override
  State<VideoMenu> createState() => _VideoMenuState();
}

class _VideoMenuState extends State<VideoMenu> {
  PageController pageController = PageController(initialPage: 0);
  VideoPlayerController _Controller;
  bool isLoading;
  @override
  void initState() {
    super.initState();
    getVideo();
    isLoading = true;
  }

  @override
  void dispose() {
    _Controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            color: Colors.black,
            child: Stack(
              children: [
                PageView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: videoNews.length,
                  itemBuilder: (context, index){
                    return Stack(
                      children: [
                        Center(
                          child: VideoWidget(
                            url: videoNews[index].videoUrls,
                            play: true,
                          ),
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: VideoBottomMenu(
                                    title: videoNews[index].title,
                                    slug: videoNews[index].slug,
                                    desc: videoNews[index].description,
                                    videourl: videoNews[index].videoUrls,
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: VideoSideBar(
                                    title: videoNews[index].title,
                                    videourl: videoNews[index].videoUrls,
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      ],
                    );
                  },
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(10, 10, 0, 0),
                  child: Image(image: AssetImage("Assets/images/sitelogo.png"),width: 100),
                ),
              ],
            )
        ),
      ),
    );
  }

  Future<VideoNewsModel> videoNewsObj;
  List<VNews> videoNews = [];
  List<VData> videoData = [];

  getVideo() async {
    setState(() {
      isLoading = true;
    });
    try {
      videoNewsObj = ApiFuture().videoNews(ApiUrl.AllVideo);
      await videoNewsObj.then((value) async {
        videoNews.addAll(value.data.news);
        videoData.add(value.data);
      });
      setState(() {
        isLoading = false;
      });
    } on SocketException {
      setState(() {
        isLoading = false;
      });
      Fluttertoast.showToast(msg: "Internet Connection Problem",backgroundColor: PurpleColor,textColor: Colors.white);
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      //Fluttertoast.showToast(msg: "Data Fetching Error",backgroundColor: PurpleColor,textColor: Colors.white);
      print(e);
    }
    setState(() {});
  }
}

class VideoWidget extends StatefulWidget {

  final bool play;
  final String url;

  VideoWidget({Key key, @required this.url, @required this.play}) : super(key: key);

  @override
  _VideoWidgetState createState() => _VideoWidgetState();
}


class _VideoWidgetState extends State<VideoWidget> {
  VideoPlayerController videoPlayerController ;
  Future<void> _initializeVideoPlayerFuture;
  bool isLoading;
  @override
  void initState() {
    super.initState();
    //videoPlayerController = VideoPlayerController.network("https://player.vimeo.com/external/539033394.hd.mp4?s=4a924ed8ab86e02f62f2458f134d2374ee6b6907&profile_id=174&oauth2_token_id=57447761");
    videoPlayerController = VideoPlayerController.network(widget.url);
    _initializeVideoPlayerFuture = videoPlayerController.initialize().then((_) {
      videoPlayerController.play();
      videoPlayerController.setLooping(true);
      setState(() {});
    });
  } // This closing tag was missing

  @override
  void dispose() {
    videoPlayerController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return videoPlayerController.value.isInitialized ? InkWell(
      onTap: videoPlayerController.pause,
      onDoubleTap: videoPlayerController.play,
      child: Container(
        width: MediaQuery.of(context).size.width,
        //height: MediaQuery.of(context).size.height / videoPlayerController.value.aspectRatio,
        child: AspectRatio(
            aspectRatio: videoPlayerController.value.aspectRatio,
            child: VideoPlayer(videoPlayerController)
        ),
      ),
    ) : const Center(child: CircularProgressIndicator(color: Colors.white70,));
  }
}