// ignore_for_file: constant_identifier_names

class ApiUrl{

  static const Url = "https://newgujarati.news/api/";

  static const CategoryNameID = Url + "get-categories";

  static const AllNews = Url + "all-news";

  static const AllVideo = Url + "all-videos";

  static const LiveWireDetails = Url + "thread-details";

  static const AllLiveWire = Url + "all-threads";
}

// static const Url = "https://trialatwork.com/newgnews/api/";